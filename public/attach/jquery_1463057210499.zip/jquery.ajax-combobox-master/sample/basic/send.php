<pre><?php print_r($_POST) ?></pre>
<a href="./">Back</a>